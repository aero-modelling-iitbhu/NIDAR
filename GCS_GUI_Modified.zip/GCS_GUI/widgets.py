import cv2
import sys
import os
import subprocess
import time
from PyQt6.QtWidgets import (QWidget, QLabel, QVBoxLayout, QPushButton, 
                             QFrame, QSizePolicy, QMessageBox)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl, QTimer
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWebEngineWidgets import QWebEngineView

class VideoThread(QThread):
    change_pixmap_signal = pyqtSignal(QImage)

    def __init__(self, source=0):
        super().__init__()
        self.source = source
        self._run_flag = True

    def run(self):
        # capture from web cam
        cap = cv2.VideoCapture(self.source)
        while self._run_flag:
            ret, cv_img = cap.read()
            if ret:
                rgb_image = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
                h, w, ch = rgb_image.shape
                bytes_per_line = ch * w
                convert_to_qt_format = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
                p = convert_to_qt_format.scaled(640, 480, Qt.AspectRatioMode.KeepAspectRatio)
                self.change_pixmap_signal.emit(p)
            else:
                # If no camera, sleep a bit to avoid busy loop
                time.sleep(1)
        # shut down capture system
        cap.release()

    def stop(self):
        self._run_flag = False
        self.wait()

class VideoWidget(QWidget):
    def __init__(self, source=0, title="Camera Stream"):
        super().__init__()
        self.setWindowTitle(title)
        self.disply_width = 640
        self.display_height = 480
        
        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("font-weight: bold; color: white; background-color: #333; padding: 5px;")

        self.image_label = QLabel(self)
        self.image_label.setScaledContents(True)
        self.image_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.image_label.setStyleSheet("background-color: black;")
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setText("No Signal")

        layout = QVBoxLayout()
        layout.addWidget(self.title_label)
        layout.addWidget(self.image_label)
        layout.setContentsMargins(0,0,0,0)
        self.setLayout(layout)

        self.source = source
        self.thread = VideoThread(source)
        self.thread.change_pixmap_signal.connect(self.update_image)
        self.thread.start()

    def update_image(self, qt_img):
        self.image_label.setPixmap(QPixmap.fromImage(qt_img))

    def closeEvent(self, event):
        self.thread.stop()
        event.accept()

class WebWidget(QWidget):
    def __init__(self, url="https://google.com", title="Web View"):
        super().__init__()
        
        self.title_label = QLabel(title)
        self.title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label.setStyleSheet("font-weight: bold; color: white; background-color: #333; padding: 5px;")

        self.browser = QWebEngineView()
        self.browser.setUrl(QUrl(url))

        layout = QVBoxLayout()
        layout.addWidget(self.title_label)
        layout.addWidget(self.browser)
        layout.setContentsMargins(0,0,0,0)
        self.setLayout(layout)

class QGCLauncherWidget(QWidget):
    def __init__(self, app_path="./QGroundControl.AppImage"):
        super().__init__()
        self.app_path = app_path
        self.process = None

        # Just a simple button now
        self.launch_btn = QPushButton("Launch QGC (Split Screen)")
        self.launch_btn.clicked.connect(self.launch_qgc)
        self.launch_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3; 
                color: white; 
                padding: 12px; 
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        
        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #aaa; margin-left: 10px;")

        layout = QVBoxLayout()
        layout.addWidget(self.launch_btn)
        layout.addWidget(self.status_label)
        layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(layout)

    def launch_qgc(self):
        # Resolve path
        if not os.path.exists(self.app_path):
             # Try common locations
             candidates = [
                 os.path.join(os.getcwd(), "QGroundControl.AppImage"),
                 os.path.join(os.path.dirname(__file__), "QGroundControl.AppImage"),
                 os.path.expanduser("~/Desktop/QGroundControl.AppImage")
             ]
             for c in candidates:
                 if os.path.exists(c):
                     self.app_path = c
                     break
        
        if not os.path.exists(self.app_path):
             self.status_label.setText("Error: QGC AppImage not found")
             return

        try:
            # Force X11 backend just in case
            env = os.environ.copy()
            env["QT_QPA_PLATFORM"] = "xcb"
            
            os.chmod(self.app_path, 0o755)
            self.process = subprocess.Popen([self.app_path], env=env)
            self.status_label.setText("Launching...")
            self.launch_btn.setEnabled(False)
            
            # Start checking for the window to position it
            QTimer.singleShot(2000, self.check_for_window_and_move)
        except Exception as e:
            self.status_label.setText(f"Failed: {str(e)}")
            self.launch_btn.setEnabled(True)

    def check_for_window_and_move(self):
        wid = self.find_qgc_wid()
        if wid:
            self.position_qgc_window(wid)
            self.status_label.setText("QGC Launched & Positioned")
            self.launch_btn.setEnabled(True)
        else:
            # Keep checking
            QTimer.singleShot(1000, self.check_for_window_and_move)

    def find_qgc_wid(self):
        try:
            output = subprocess.check_output(['xwininfo', '-root', '-tree']).decode('utf-8', errors='ignore')
            for line in output.splitlines():
                low_line = line.lower()
                if "qgroundcontrol" in low_line:
                    if "selection owner" in low_line: continue
                    
                    parts = line.strip().split()
                    if parts and parts[0].startswith('0x'):
                        try:
                            # 1x1 filter
                            if "1x1+" in line or "3x3+" in line: continue
                            
                            wid = int(parts[0], 16)
                            return wid
                        except ValueError:
                            continue
        except Exception as e:
            print(f"Error finding window: {e}")
        return None

    def position_qgc_window(self, wid):
        # Move QGC to Left Half of screen (0, 0, 960, 1080)
        # Assuming 1080p screen.
        target_x = 0
        target_y = 0
        target_w = 960
        target_h = 1000 # Leave some taskbar space maybe? Or 1080.
        
        print(f"Moving QGC {hex(wid)} to {target_x},{target_y} {target_w}x{target_h}")
        if sys.platform.startswith("linux"):
             self.x11_move_resize(wid, target_x, target_y, target_w, target_h)

    def x11_move_resize(self, wid, x, y, w, h):
        try:
            import ctypes
            from ctypes import c_void_p, c_ulong, c_int

            x11 = ctypes.cdll.LoadLibrary("libX11.so.6")
            
            x11.XOpenDisplay.restype = c_void_p
            x11.XMoveResizeWindow.argtypes = [c_void_p, c_ulong, c_int, c_int, c_int, c_int]
            x11.XMapWindow.argtypes = [c_void_p, c_ulong]
            x11.XFlush.argtypes = [c_void_p]
            x11.XRaiseWindow.argtypes = [c_void_p, c_ulong]

            display = x11.XOpenDisplay(None)
            if not display: return

            # Unmaximize if necessary (some WMs ignore move if maximized)
            # This is hard to do via raw X11 quickly, but moving usually works.
            
            x11.XMoveResizeWindow(display, wid, x, y, w, h)
            x11.XRaiseWindow(display, wid)
            x11.XMapWindow(display, wid)
            x11.XFlush(display)
            
        except Exception as e:
            print(f"X11 Move failed: {e}")

def setup_logging():
    pass 


if __name__ == "__main__":
    setup_logging()  # Only effective if running this file directly, but we need it in main too


