import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QGridLayout, 
                             QLabel, QVBoxLayout, QFrame, QHBoxLayout)
from PyQt6.QtCore import QFile, QTextStream

from widgets import VideoWidget, WebWidget, QGCLauncherWidget, setup_logging

class GCSMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Ground Control Station Console")
        # Half screen width (simulated for 1080p screen: 1920/2 = 960)
        self.resize(960, 1000)
        # Move to the RIGHT side of the screen
        self.move(960, 0)
 
        # Main Central Widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
 
        # Layout
        # Top: Toolbar (QGC Launch)
        # Center: 2x2 Grid for Cameras/RPi
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # 1. Top Bar
        top_bar = QFrame()
        top_bar.setStyleSheet("background-color: #333; padding: 5px;")
        top_layout = QHBoxLayout()
        top_bar.setLayout(top_layout)
        
        # Path to QGC
        qgc_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "QGroundControl.AppImage")
        self.qgc_controller = QGCLauncherWidget(app_path=qgc_path)
        
        top_layout.addWidget(QLabel("<b>NIDAR SYSTEM</b>"))
        top_layout.addStretch()
        top_layout.addWidget(self.qgc_controller)
        
        main_layout.addWidget(top_bar)

        # 2. Grid Content
        grid_layout = QGridLayout()
        
        # Web Views (RPi Connect)
        self.rpi_connect_drone_1 = WebWidget(url="https://www.raspberrypi.com/software/connect/", title="RPi Connect - Drone 1")
        self.rpi_connect_drone_2 = WebWidget(url="https://www.raspberrypi.com/software/connect/", title="RPi Connect - Drone 2")
        
        # Camera Streams
        self.camera_drone_1 = VideoWidget(source=0, title="Camera Stream - Drone 1")
        self.camera_drone_2 = VideoWidget(source=2, title="Camera Stream - Drone 2")
 
        # Add to Grid (2x2)
        grid_layout.addWidget(self.rpi_connect_drone_1, 0, 0)
        grid_layout.addWidget(self.rpi_connect_drone_2, 0, 1)
        grid_layout.addWidget(self.camera_drone_1, 1, 0)
        grid_layout.addWidget(self.camera_drone_2, 1, 1)

        # Force Equal Columns
        grid_layout.setColumnStretch(0, 1)
        grid_layout.setColumnStretch(1, 1)

        main_layout.addLayout(grid_layout)

def main():
    setup_logging()
    app = QApplication(sys.argv)
    
    # Load Stylesheet
    style_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "style.qss")
    if os.path.exists(style_file):
        with open(style_file, "r") as f:
            app.setStyleSheet(f.read())
            
    window = GCSMainWindow()
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
