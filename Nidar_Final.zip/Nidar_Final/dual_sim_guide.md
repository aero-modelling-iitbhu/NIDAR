# Dual Drone Simulation Guide

To test both drones on a single laptop, you need to run two separate SITL instances and connected scripts.

## Prerequisites
-   ArduPilot/ArduCopter development environment set up (`sim_vehicle.py` available in path).
-   `setup_sitl.bash` or similar environment loaded.

## 1. Start Drone 1 (Survey Drone)
Open **Terminal 1** and run:
```bash
# Instance 0 (default)
sim_vehicle.py -v ArduCopter --console --map -w
# This listens for MAVLink on udp:127.0.0.1:14550 (GCS) and 14551 (API)
```

## 2. Start Drone 2 (Delivery Drone)
Open **Terminal 2** and run:
```bash
# Instance 1
# -I 1 offsets ports by 10 (14560, 14561, etc.)
# But we need to be careful with port mapping.
# Standard ArduPilot SITL multi-vehicle uses -I.
sim_vehicle.py -v ArduCopter -I 1 --console --map
# OUTPUTS:
# Master: tcp:127.0.0.1:5770
# SITL: 127.0.0.1:5510
# MAVLink Output: udp:127.0.0.1:14560 (GCS), udp:127.0.0.1:14561 (API)
```
*Note: If you want specific ports like 14553, you might need MAVProxy forwarding, but usually 14560/14561 is standard for Instance 1.*

## 3. Run Survey Script (Drone 1)
Open **Terminal 3**:
```bash
cd ~/Desktop/Nidar_Final
# Connect to Instance 0 (14551 is standard output)
python3 survey.py --connect udp:127.0.0.1:14551
```
*This handles detections and runs `mqtt_transfer.py --sender` in background.*

## 4. Run Delivery Script (Drone 2)
Open **Terminal 4**:
```bash
cd ~/Desktop/Nidar_Final/Delivery_Drone
# Start MQTT Receiver first (background)
python3 mqtt_transfer.py --mode receiver &

# Run Delivery Mission
# We need to connect to Instance 1.
# Default Instance 1 output is usually 14560 or 14561.
# Let's try 14561.
python3 delivery_drone.py --connect udp:127.0.0.1:14561
```

## Troubleshooting
-   If `14561` doesn't work for Drone 2, check the MAVProxy console output in Terminal 2 for "MAVLink Output".
-   If you need to force port 14553 for Drone 2:
    In Terminal 2 MAVProxy: `output add 127.0.0.1:14553`
