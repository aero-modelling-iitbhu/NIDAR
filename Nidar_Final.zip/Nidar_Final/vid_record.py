import cv2
import datetime

def record_webcam(output_filename='output.avi', fps=20.0):
    # 1. Open the video capture (0 is usually the default webcam)
    cap = cv2.VideoCapture(0)

    # Check if opened successfully
    if not cap.isOpened():
        print("Error: Could not open video device.")
        return

    # 2. Get frame dimensions
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    print(f"Camera Resolution: {frame_width}x{frame_height}")

    # 3. Define the codec and create VideoWriter object
    # 'XVID' is a widely supported codec for .avi
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter(output_filename, fourcc, fps, (frame_width, frame_height))

    print(f"Recording to {output_filename}...")
    print("Press 'q' to stop recording.")

    while True:
        # 4. Capture frame-by-frame
        ret, frame = cap.read()

        if not ret:
            print("Error: Can't receive frame (stream end?). Exiting ...")
            break

        # 5. Write the frame
        out.write(frame)

        # 6. Display the resulting frame
        cv2.imshow('Webcam Recording', frame)

        # 7. Check for 'q' key to quit
        if cv2.waitKey(1) & 0xFF == ord('q'):
            print("Stop signal received.")
            break

    # 8. Release everything when done
    cap.release()
    out.release()
    cv2.destroyAllWindows()
    print("Video saved.")

if __name__ == "__main__":
    # Generate a timestamped filename
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"video_{timestamp}.avi"
    
    record_webcam(output_filename=filename)
