import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, 
                             QLabel, QVBoxLayout, QFrame, QHBoxLayout)
from PyQt6.QtCore import QFile, QTextStream, Qt
from PyQt6.QtGui import QPixmap

from widgets import WebWidget, QGCLauncherWidget, setup_logging

class GCSMainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ResQWings GCS")
        self.showMaximized() # Full Screen (Windowed)
        self.setObjectName("MainWindow")

        # Main Central Widget
        central_widget = QWidget()
        central_widget.setObjectName("CentralWidget")
        self.setCentralWidget(central_widget)
 
        # Layout
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        central_widget.setLayout(main_layout)
        
        # 1. Top Bar (Header)
        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_layout = QHBoxLayout()
        top_layout.setContentsMargins(20, 10, 20, 10)
        top_bar.setLayout(top_layout)
        
        # Logo and Title
        logo_label = QLabel()
        logo_pixmap = QPixmap(os.path.join(os.path.dirname(os.path.abspath(__file__)), "logo.png"))
        if not logo_pixmap.isNull():
            logo_label.setPixmap(logo_pixmap.scaled(64, 64, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        top_layout.addWidget(logo_label)

        title_label = QLabel("RESQWINGS")
        title_label.setObjectName("HeaderTitle")
        top_layout.addWidget(title_label)
        
        top_layout.addStretch()

        # Path to QGC
        qgc_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "QGroundControl.AppImage")
        # Check if user has it in home
        home_qgc = os.path.expanduser("~/QGroundControl-x86_64.AppImage")
        if os.path.exists(home_qgc):
             qgc_path = home_qgc
             
        self.qgc_controller = QGCLauncherWidget(app_path=qgc_path)
        top_layout.addWidget(self.qgc_controller)
        
        main_layout.addWidget(top_bar)

        # 2. Content Area (Split)
        content_layout = QHBoxLayout()
        main_layout.addLayout(content_layout)

        # LEFT SIDE: Placeholder for QGC (Transparent/Interactive Area)
        # We can add a label saying "QGC DROP ZONE" or just leave it transparent
        left_frame = QFrame()
        left_frame.setStyleSheet("background-color: rgba(0,0,0,0.2); border-right: 2px dashed #004455;")
        left_layout = QVBoxLayout()
        left_frame.setLayout(left_layout)
        
        # Optional: Add a subtle target/grid overlay
        drop_label = QLabel("MISSION CONTROL\n[ Awaiting QGC Link ]")
        drop_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        drop_label.setStyleSheet("color: #005577; font-weight: bold; font-size: 20px;")
        left_layout.addStretch()
        left_layout.addWidget(drop_label)
        left_layout.addStretch()

        content_layout.addWidget(left_frame, 1) # Stretch 1 (50%)

        # RIGHT SIDE: Web Widgets
        right_frame = QFrame()
        right_layout = QVBoxLayout()
        right_frame.setLayout(right_layout)
        
        # Drone 1 Page
        self.rpi_connect_drone_1 = WebWidget(url="https://connect.raspberrypi.com/devices/99881bd9-aea1-44af-8d56-38a281b017e7/screen-sharing-session", title="DRONE 1 [LIVE]")
        self.rpi_connect_drone_1.setObjectName("WebContainer")
        
        # Drone 2 Page
        self.rpi_connect_drone_2 = WebWidget(url="https://connect.raspberrypi.com/devices/269d067e-e56a-4c65-9f7b-cd6553dbe439/screen-sharing-session", title="DRONE 2 [LIVE]")
        self.rpi_connect_drone_2.setObjectName("WebContainer")
        
        # Add to Right Layout
        right_layout.addWidget(self.rpi_connect_drone_1)
        right_layout.addWidget(self.rpi_connect_drone_2)

        content_layout.addWidget(right_frame, 1) # Stretch 1 (50%)

def main():
    setup_logging()
    app = QApplication(sys.argv)
    
    # Load Stylesheet
    style_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "style.qss")
    if os.path.exists(style_file):
        with open(style_file, "r") as f:
            app.setStyleSheet(f.read())
            
    window = GCSMainWindow()
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
