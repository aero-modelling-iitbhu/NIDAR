'''
Sim to Raspi: 25, 28, 260

'''

import time
import csv
import math
import os
import argparse
from pymavlink import mavutil
from geopy.distance import geodesic
from geopy.distance import geodesic
import threading

# GPIO Handling (Safe import for Simulation)
try:
    from gpiozero import Servo, Buzzer
    GPIO_AVAILABLE = True
except ImportError:
    print("gpiozero not found. Running in SIMULATION mode (Mock GPIO).")
    GPIO_AVAILABLE = False
    
    class Servo:
        def __init__(self, pin): pass
        def min(self): print("SIM: Servo MIN (Closed)")
        def max(self): print("SIM: Servo MAX (Open)")
        
    class Buzzer:
        def __init__(self, pin): pass
        def on(self): print("SIM: Buzzer ON")
        def off(self): print("SIM: Buzzer OFF")

# Configuration
MAVLINK_CONNECTION = "/dev/ttyACM0" # Adjust as needed for specific drone
TRAVEL_ALTITUDE = 20.0 # meters
DROP_ALTITUDE = 6.0    # meters
DROP_HOVER_TIME = 10   # seconds
TRAVEL_ALTITUDE = 15.0 # meters
DROP_ALTITUDE = 6.0    # meters
DROP_HOVER_TIME = 10   # seconds
REFILL_WAIT_TIME = 300 # seconds (5 mins)
BATCH_SIZE = 5

# GPIO Config
SERVO_PINS = [17, 18, 22, 23, 27]
BUZZER_PIN = 15

class DeliveryDrone:
    # def __int__(self, connection_string='/dev/ttyACM0'):
    def __init__(self, connection_string):
        print(f"Connecting to drone on {connection_string}...")
        # self.master = mavutil.mavlink_connection(connection_string, baud=115200, autoreconnect=True)
        self.master = mavutil.mavlink_connection(connection_string)
        self.master.wait_heartbeat()
        print("Heartbeat received!")
        
        self.processed_indices = set() # Keep track of lines read from CSV
        self.home_location = None
        
        # Initialize Payload Mechanism
        self.servos = []
        try:
             self.buzzer = Buzzer(BUZZER_PIN)
             self.buzzer.off()
             
             for pin in SERVO_PINS:
                 s = Servo(pin)
                 s.min() # Start closed
                 self.servos.append(s)
                 
        except Exception as e:
             print(f"GPIO Init Failed: {e}")

    def get_position(self):
        msg = self.master.recv_match(type='GLOBAL_POSITION_INT', blocking=True, timeout=5)
        if msg:
            lat = msg.lat / 1e7
            lon = msg.lon / 1e7
            alt = msg.relative_alt / 1000.0
            return lat, lon, alt
        return None

    def set_mode(self, mode):
        try:
            self.master.set_mode(mode)
            print(f"Set mode to {mode}")
            time.sleep(1.0)
        except Exception as e:
            print(f"Failed to set mode {mode}: {e}")

    def arm(self):
        print("Arming motors...")
        while not self.master.motors_armed():
            try:
                self.master.arducopter_arm()
                self.master.motors_armed_wait()
            except:
                pass
            
            if self.master.motors_armed():
                print("Armed successfully!")
                break
            
            print("Waiting for arming... Retrying in 0.5s")
            time.sleep(0.5)

    def takeoff(self, target_altitude):
        # 1. Set Mode GUIDED
        self.set_mode("GUIDED")
        
        # 2. Arm
        self.arm()
        time.sleep(5.0)
        
        # 3. Takeoff Command
        print(f"Taking off to {target_altitude}m...")
        try:
            self.master.mav.command_long_send(
                self.master.target_system,
                self.master.target_component,
                mavutil.mavlink.MAV_CMD_NAV_TAKEOFF,
                0, 0, 0, 0, 0, 0, 0, target_altitude
            )
        except Exception as e:
            print(f"Failed to send takeoff: {e}")
            return

        # 4. Wait Loop
        print("Waiting to reach takeoff altitude...")
        start = time.time()
        while time.time() - start < 60:
            pos = self.get_position()
            if pos is not None:
                _, _, cur_alt = pos
                print(f"Current altitude: {cur_alt:.1f} m")
                if abs(cur_alt - target_altitude) <= 2.0:
                    print("Reached takeoff altitude.")
                    break
            time.sleep(0.1)

    def goto_location(self, lat, lon, alt):
        print(f"Going to {lat:.6f}, {lon:.6f}, {alt:.1f}m")
        self.master.mav.set_position_target_global_int_send(
            0, self.master.target_system, self.master.target_component,
            mavutil.mavlink.MAV_FRAME_GLOBAL_RELATIVE_ALT,
            0b110111111000, # Use position only
            int(lat * 1e7), int(lon * 1e7), alt,
            0, 0, 0, 0, 0, 0, 0, 0
        )
        
        while True:
            pos = self.get_position()
            if pos:
                d_lat = pos[0] - lat
                d_lon = pos[1] - lon
                d_alt = abs(pos[2] - alt)
                
                dist = math.sqrt(d_lat**2 + d_lon**2) * 1.113195e5 # Approx meters
                
                if dist < 1.0 and d_alt < 1.0:
                    print("Reached target.")
                    break
            time.sleep(0.1)

            time.sleep(0.1)

    def deliver_payload(self, index):
        print(f"Deploying Payload {index+1}...")
        if hasattr(self, 'buzzer') and self.servos and index < len(self.servos):
            try:
                servo = self.servos[index]
                self.buzzer.on()
                servo.max() # Open
                time.sleep(2.0)
                servo.min() # Close
                self.buzzer.off()
            except Exception as e:
                print(f"Payload Error: {e}")
        else:
             print("Payload mechanism not ready or index out of range.")
        print("Payload Deployed.")

    def execute_drop_sequence(self, lat, lon, index):
        print(f"Starting drop sequence for {lat:.6f}, {lon:.6f} using Servo {index+1}")
        
        # 1. Go to location at travel altitude
        self.goto_location(lat, lon, TRAVEL_ALTITUDE)
        
        # 2. Descend to drop altitude
        print(f"Descending to {DROP_ALTITUDE}m...")
        self.goto_location(lat, lon, DROP_ALTITUDE)
        
        # 3. Hover & Drop
        print(f"Hovering for {DROP_HOVER_TIME} seconds...")
        self.deliver_payload(index) # Drop payload
        time.sleep(DROP_HOVER_TIME)
        
        # 4. Ascend back to travel altitude
        print(f"Ascending to {TRAVEL_ALTITUDE}m...")
        self.goto_location(lat, lon, TRAVEL_ALTITUDE)
        print("Drop sequence complete.")

    def return_to_launch(self):
        print("Returning to Launch (RTL)...")
        self.set_mode("RTL")
        # Monitor until landed/disarmed? 
        # For this script loop, we wait until disarmed or low altitude
        while True:
            msg = self.master.recv_match(type='HEARTBEAT', blocking=True)
            if not msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED:
                print("Drone disarmed. Landed.")
                break
            time.sleep(1)

    def optimize_path(self, start_pos, points):
        # Simple Greedy Nearest Neighbor
        path = []
        current = start_pos # (lat, lon)
        remaining = points.copy() # List of (lat, lon)
        
        print("Optimizing path...")
        while remaining:
            nearest = min(remaining, key=lambda p: geodesic(current, p).meters)
            path.append(nearest)
            remaining.remove(nearest)
            current = nearest
            
        return path

    def wait_for_batch(self, csv_filename):
        print(f"Waiting for {BATCH_SIZE} new waypoints in {csv_filename}...")
        collected_points = []
        
        while True:
            if not os.path.exists(csv_filename):
                time.sleep(1)
                continue
                
            with open(csv_filename, 'r') as f:
                reader = csv.reader(f)
                rows = list(reader)
                
                # Filter rows we haven't processed yet
                # Assuming first row is header if "latitude" in it
                start_idx = 1 if rows and "latitude" in rows[0] else 0
                
                new_points = []
                for i in range(start_idx, len(rows)):
                    if i not in self.processed_indices:
                        try:
                            lat = float(rows[i][1])
                            lon = float(rows[i][2])
                            new_points.append((lat, lon))
                            # Don't mark processed yet, wait until we have full batch
                        except:
                            pass
                
                # Check if we have enough new points to form a batch
                # We need to find the *next* 5 points
                
                # Actually, simpler logic:
                # Just grab the next 5 unprocessed indices
                
                batch_indices = []
                batch_coords = []
                
                for i in range(start_idx, len(rows)):
                    if i not in self.processed_indices:
                        try:
                            lat = float(rows[i][1])
                            lon = float(rows[i][2])
                            batch_indices.append(i)
                            batch_coords.append((lat, lon))
                        except:
                            pass
                        
                        if len(batch_coords) == BATCH_SIZE:
                            break
                
                if len(batch_coords) == BATCH_SIZE:
                    # We have a batch!
                    print(f"Batch collected: {len(batch_coords)} points.")
                    
                    # Mark as processed
                    for idx in batch_indices:
                        self.processed_indices.add(idx)
                        
                    return batch_coords
            
            time.sleep(2)

    def run(self):
        # Save home location
        print("Waiting for GPS lock to save Home...")
        while True:
            pos = self.get_position()
            if pos:
                self.home_location = (pos[0], pos[1])
                print(f"Home location saved: {self.home_location}")
                break
            time.sleep(1)

        batch_id = 1
        while True:
            # 1. Wait for 5 waypoints from current batch file
            current_csv = f"human_locations_{batch_id}.csv"
            # Reset processed indices for new file
            self.processed_indices = set()
            
            targets = self.wait_for_batch(current_csv)
            
            # 2. Optimize Path
            current_pos = self.get_position()
            current_latlon = (current_pos[0], current_pos[1])
            optimized_targets = self.optimize_path(current_latlon, targets)
            
            # 3. Takeoff
            self.takeoff(TRAVEL_ALTITUDE)
            
            # 4. Execute Deliveries
            for i, target in enumerate(optimized_targets):
                print(f"--- Delivery {i+1}/{BATCH_SIZE} ---")
                # Ensure we don't exceed available servos
                servo_idx = i % len(SERVO_PINS)
                self.execute_drop_sequence(target[0], target[1], servo_idx)
            
            # 5. Return to Launch
            self.return_to_launch()
            
            # 6. Wait for Refill
            print(f"Mission Complete. Waiting {REFILL_WAIT_TIME} seconds for refill...")
            time.sleep(REFILL_WAIT_TIME)
            print("Refill complete. Ready for next batch.")
            
            # Increment batch ID for next iteration
            batch_id += 1

def main():
    parser = argparse.ArgumentParser()
    # parser.add_argument('--connect', type=str, default='/dev/ttyACM0', help='MAVLink connection string')
    parser.add_argument('--connect', default='udp:127.0.0.1:14551', help='MAVLink connection string')
    args = parser.parse_args()
    
    drone = DeliveryDrone(args.connect)
    drone.run()

if __name__ == "__main__":
    main()
